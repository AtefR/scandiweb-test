<?php

declare(strict_types=1);

const DB_USER = 'id21921710_scandiweb';
const DB_PASSWORD = 'Sc@abd1web';
const DB_HOST = 'localhost';
const DB_NAME = 'id21921710_scandiweb';