<?php

declare(strict_types=1);

require_once __DIR__.'/vendor/autoload.php';

use Core\Http\Router;
use Infrastructure\Http\Product\CreateController;
use Infrastructure\Http\Product\DeleteController;
use Infrastructure\Http\Product\IndexController;

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true ");
header("Access-Control-Allow-Methods: OPTIONS, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Depth, User-Agent, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control");

$router = new Router();

$router->addRoute('GET', '/', function () {
    echo "Hello world!";
    exit;
});

$router->addRoute('GET', '/products', IndexController::class);

$router->addRoute('POST', '/products', CreateController::class);

$router->addRoute('DELETE', '/products', DeleteController::class);

$router->matchRoute();
